import 'package:flutter/material.dart';
import 'part_a/task1_username_screen.dart';
import 'part_a/task2_counter_screen.dart';
import 'part_a/task3_dark_mode_screen.dart';
import 'part_b/task4_database_setup_screen.dart';
import 'part_b/task5_insert_read_screen.dart';
import 'part_b/task6_update_delete_screen.dart';
import 'part_c/task7_full_crud_screen.dart';
import 'part_d/task9_file_storage_screen.dart';
import 'part_d/task10_hybrid_storage_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Persistence Lab'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSectionHeader('Part A - Shared Preferences (25 points)'),
          _buildTaskCard(
            context,
            'Task 1: Saving Simple Data',
            'Store and retrieve username using SharedPreferences',
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const Task1UsernameScreen()),
            ),
          ),
          _buildTaskCard(
            context,
            'Task 2: Counter Persistence',
            'Counter that remembers its value after restart',
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const Task2CounterScreen()),
            ),
          ),
          _buildTaskCard(
            context,
            'Task 3: Dark Mode Toggle',
            'Theme switch with persistent preference',
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const Task3DarkModeScreen()),
            ),
          ),
          const SizedBox(height: 20),
          _buildSectionHeader('Part B - SQLite Basics (35 points)'),
          _buildTaskCard(
            context,
            'Task 4: Database Setup',
            'Create and initialize SQLite database',
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const Task4DatabaseSetupScreen()),
            ),
          ),
          _buildTaskCard(
            context,
            'Task 5: Insert and Read Records',
            'Add and view notes from database',
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const Task5InsertReadScreen()),
            ),
          ),
          _buildTaskCard(
            context,
            'Task 6: Update and Delete Records',
            'Edit and delete notes with confirmation',
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const Task6UpdateDeleteScreen()),
            ),
          ),
          const SizedBox(height: 20),
          _buildSectionHeader('Part C - CRUD UI Integration (25 points)'),
          _buildTaskCard(
            context,
            'Task 7 & 8: Full CRUD Note App',
            'Complete note app with navigation',
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const Task7FullCrudScreen()),
            ),
          ),
          const SizedBox(height: 20),
          _buildSectionHeader('Part D - Advanced Persistence (15 points)'),
          _buildTaskCard(
            context,
            'Task 9: File Storage Demo',
            'Store and read text files',
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const Task9FileStorageScreen()),
            ),
          ),
          _buildTaskCard(
            context,
            'Task 10: Hybrid Storage App',
            'Combine SharedPreferences and SQLite',
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const Task10HybridStorageScreen()),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildTaskCard(
    BuildContext context,
    String title,
    String description,
    VoidCallback onTap,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(description),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: onTap,
      ),
    );
  }
}
