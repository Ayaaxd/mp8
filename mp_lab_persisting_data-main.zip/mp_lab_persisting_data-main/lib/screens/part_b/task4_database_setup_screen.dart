import 'package:flutter/material.dart';
import '../../database/database_helper.dart';

class Task4DatabaseSetupScreen extends StatefulWidget {
  const Task4DatabaseSetupScreen({Key? key}) : super(key: key);

  @override
  State<Task4DatabaseSetupScreen> createState() =>
      _Task4DatabaseSetupScreenState();
}

class _Task4DatabaseSetupScreenState extends State<Task4DatabaseSetupScreen> {
  bool _isInitialized = false;
  String _databasePath = '';

  @override
  void initState() {
    super.initState();
    _initializeDatabase();
  }

  Future<void> _initializeDatabase() async {
    try {
      final db = await DatabaseHelper.instance.database;
      setState(() {
        _isInitialized = true;
        _databasePath = db.path;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error initializing database: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Task 4: Database Setup'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          _isInitialized ? Icons.check_circle : Icons.pending,
                          color: _isInitialized ? Colors.green : Colors.orange,
                          size: 32,
                        ),
                        const SizedBox(width: 12),
                        const Text(
                          'Database Status',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      _isInitialized
                          ? '✅ Database initialized successfully!'
                          : '⏳ Initializing database...',
                      style: TextStyle(
                        fontSize: 16,
                        color: _isInitialized ? Colors.green : Colors.orange,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            if (_isInitialized)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Database Information',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      _buildInfoRow('Database Name:', 'notes.db'),
                      _buildInfoRow('Table Name:', 'notes'),
                      _buildInfoRow('Columns:', 'id, title, content'),
                      const Divider(height: 24),
                      const Text(
                        'Database Path:',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 4),
                      SelectableText(
                        _databasePath,
                        style: const TextStyle(
                          fontSize: 12,
                          fontFamily: 'monospace',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 16),
            const Card(
              color: Colors.blue,
              child: Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'ℹ️ Database Schema',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Table: notes\n'
                      '├─ id: INTEGER PRIMARY KEY\n'
                      '├─ title: TEXT NOT NULL\n'
                      '└─ content: TEXT NOT NULL',
                      style: TextStyle(
                        color: Colors.white,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const Spacer(),
            const Card(
              color: Colors.green,
              child: Padding(
                padding: EdgeInsets.all(12.0),
                child: Text(
                  '✅ This demonstrates:\n'
                  '• Adding sqflite and path_provider packages\n'
                  '• Creating a SQLite database\n'
                  '• Defining a table structure\n'
                  '• Initializing the database on app start',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        children: [
          Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }
}
