import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../database/database_helper.dart';

class Task10HybridStorageScreen extends StatefulWidget {
  const Task10HybridStorageScreen({Key? key}) : super(key: key);

  @override
  State<Task10HybridStorageScreen> createState() =>
      _Task10HybridStorageScreenState();
}

class _Task10HybridStorageScreenState extends State<Task10HybridStorageScreen> {
  // Settings (SharedPreferences)
  double _fontSize = 16.0;
  bool _isDarkTheme = false;

  // Notes (SQLite)
  List<Map<String, dynamic>> _notes = [];
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _contentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _loadNotes();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  // SharedPreferences Methods
  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _fontSize = prefs.getDouble('fontSize') ?? 16.0;
      _isDarkTheme = prefs.getBool('isDarkTheme') ?? false;
    });
  }

  Future<void> _saveFontSize(double size) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('fontSize', size);
    setState(() {
      _fontSize = size;
    });
  }

  Future<void> _saveTheme(bool isDark) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isDarkTheme', isDark);
    setState(() {
      _isDarkTheme = isDark;
    });
  }

  // SQLite Methods
  Future<void> _loadNotes() async {
    final notes = await DatabaseHelper.instance.getAllNotes();
    setState(() {
      _notes = notes;
    });
  }

  Future<void> _addNote() async {
    if (_titleController.text.isEmpty || _contentController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in all fields')),
      );
      return;
    }

    final note = {
      'title': _titleController.text,
      'content': _contentController.text,
    };

    await DatabaseHelper.instance.insertNote(note);
    _titleController.clear();
    _contentController.clear();
    _loadNotes();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Note added!')),
      );
    }
  }

  Future<void> _deleteNote(int id) async {
    await DatabaseHelper.instance.deleteNote(id);
    _loadNotes();
  }

  void _showSettingsDialog() {
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Settings'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Font Size',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Row(
                children: [
                  Text('${_fontSize.toInt()}'),
                  Expanded(
                    child: Slider(
                      value: _fontSize,
                      min: 12.0,
                      max: 24.0,
                      divisions: 12,
                      label: _fontSize.toInt().toString(),
                      onChanged: (value) {
                        setDialogState(() {
                          _fontSize = value;
                        });
                        _saveFontSize(value);
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              SwitchListTile(
                title: const Text('Dark Theme'),
                value: _isDarkTheme,
                onChanged: (value) {
                  setDialogState(() {
                    _isDarkTheme = value;
                  });
                  _saveTheme(value);
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final backgroundColor = _isDarkTheme ? Colors.grey.shade900 : Colors.white;
    final textColor = _isDarkTheme ? Colors.white : Colors.black;
    final cardColor = _isDarkTheme ? Colors.grey.shade800 : Colors.grey.shade100;

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        title: const Text('Task 10: Hybrid Storage'),
        backgroundColor: _isDarkTheme ? Colors.grey.shade900 : null,
        foregroundColor: textColor,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: _showSettingsDialog,
            tooltip: 'Settings',
          ),
        ],
      ),
      body: Column(
        children: [
          // Settings Display Card
          Container(
            padding: const EdgeInsets.all(16),
            color: _isDarkTheme ? Colors.blue.shade900 : Colors.blue.shade50,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.settings,
                      color: _isDarkTheme ? Colors.blue.shade200 : Colors.blue,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Current Settings (SharedPreferences)',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: _isDarkTheme ? Colors.blue.shade200 : Colors.blue.shade900,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  'Font Size: ${_fontSize.toInt()}px | Theme: ${_isDarkTheme ? 'Dark' : 'Light'}',
                  style: TextStyle(
                    fontSize: _fontSize,
                    color: _isDarkTheme ? Colors.blue.shade100 : Colors.blue.shade800,
                  ),
                ),
              ],
            ),
          ),
          
          // Add Note Form
          Container(
            padding: const EdgeInsets.all(16),
            color: cardColor,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Add Note (SQLite)',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: textColor,
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _titleController,
                  style: TextStyle(fontSize: _fontSize, color: textColor),
                  decoration: InputDecoration(
                    labelText: 'Title',
                    border: const OutlineInputBorder(),
                    filled: true,
                    fillColor: backgroundColor,
                    labelStyle: TextStyle(color: textColor.withOpacity(0.7)),
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _contentController,
                  style: TextStyle(fontSize: _fontSize, color: textColor),
                  decoration: InputDecoration(
                    labelText: 'Content',
                    border: const OutlineInputBorder(),
                    filled: true,
                    fillColor: backgroundColor,
                    labelStyle: TextStyle(color: textColor.withOpacity(0.7)),
                  ),
                  maxLines: 2,
                ),
                const SizedBox(height: 12),
                ElevatedButton.icon(
                  onPressed: _addNote,
                  icon: const Icon(Icons.add),
                  label: const Text('Add Note'),
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 50),
                  ),
                ),
              ],
            ),
          ),

          // Notes List
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Icon(Icons.note, color: textColor),
                const SizedBox(width: 8),
                Text(
                  'Notes (${_notes.length})',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: textColor,
                  ),
                ),
              ],
            ),
          ),
          
          Expanded(
            child: _notes.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.note_add,
                          size: 64,
                          color: textColor.withOpacity(0.3),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'No notes yet',
                          style: TextStyle(
                            fontSize: 18,
                            color: textColor.withOpacity(0.5),
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: _notes.length,
                    itemBuilder: (context, index) {
                      final note = _notes[index];
                      return Card(
                        color: cardColor,
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          title: Text(
                            note['title'],
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: _fontSize,
                              color: textColor,
                            ),
                          ),
                          subtitle: Text(
                            note['content'],
                            style: TextStyle(
                              fontSize: _fontSize - 2,
                              color: textColor.withOpacity(0.7),
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          trailing: IconButton(
                            icon: Icon(Icons.delete, color: Colors.red.shade400),
                            onPressed: () => _deleteNote(note['id']),
                          ),
                        ),
                      );
                    },
                  ),
          ),

          // Info Card
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _isDarkTheme ? Colors.green.shade900 : Colors.green.shade100,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '✅ This app demonstrates:',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: _isDarkTheme ? Colors.green.shade200 : Colors.green.shade900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '• SharedPreferences for settings (font size, theme)\n'
                  '• SQLite for structured data (notes)\n'
                  '• Real-time UI updates based on settings',
                  style: TextStyle(
                    fontSize: 12,
                    color: _isDarkTheme ? Colors.green.shade100 : Colors.green.shade800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
