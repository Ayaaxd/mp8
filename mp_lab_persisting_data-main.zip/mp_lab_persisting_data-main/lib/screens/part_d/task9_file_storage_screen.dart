import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

class Task9FileStorageScreen extends StatefulWidget {
  const Task9FileStorageScreen({Key? key}) : super(key: key);

  @override
  State<Task9FileStorageScreen> createState() => _Task9FileStorageScreenState();
}

class _Task9FileStorageScreenState extends State<Task9FileStorageScreen> {
  final TextEditingController _controller = TextEditingController();
  String _fileContent = '';
  String _filePath = '';
  bool _fileExists = false;

  @override
  void initState() {
    super.initState();
    _checkFileExists();
  }

  Future<File> _getFile() async {
    final directory = await getApplicationDocumentsDirectory();
    final path = '${directory.path}/user_data.txt';
    setState(() {
      _filePath = path;
    });
    return File(path);
  }

  Future<void> _checkFileExists() async {
    try {
      final file = await _getFile();
      setState(() {
        _fileExists = file.existsSync();
      });
      if (_fileExists) {
        _readFile();
      }
    } catch (e) {
      _showError('Error checking file: $e');
    }
  }

  Future<void> _writeFile() async {
    if (_controller.text.isEmpty) {
      _showError('Please enter some text');
      return;
    }

    try {
      final file = await _getFile();
      await file.writeAsString(_controller.text);
      
      setState(() {
        _fileExists = true;
      });
      
      _controller.clear();
      _readFile();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('File saved successfully!')),
        );
      }
    } catch (e) {
      _showError('Error writing file: $e');
    }
  }

  Future<void> _readFile() async {
    try {
      final file = await _getFile();
      if (await file.exists()) {
        final contents = await file.readAsString();
        setState(() {
          _fileContent = contents;
          _fileExists = true;
        });
      } else {
        setState(() {
          _fileContent = 'File does not exist yet.';
          _fileExists = false;
        });
      }
    } catch (e) {
      _showError('Error reading file: $e');
    }
  }

  Future<void> _deleteFile() async {
    try {
      final file = await _getFile();
      if (await file.exists()) {
        await file.delete();
        setState(() {
          _fileContent = '';
          _fileExists = false;
        });
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('File deleted successfully!')),
          );
        }
      }
    } catch (e) {
      _showError('Error deleting file: $e');
    }
  }

  void _showError(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Task 9: File Storage'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        _fileExists ? Icons.check_circle : Icons.info,
                        color: _fileExists ? Colors.green : Colors.orange,
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        'File Status',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _fileExists ? 'File exists' : 'File not created yet',
                    style: TextStyle(
                      color: _fileExists ? Colors.green : Colors.grey,
                    ),
                  ),
                  if (_filePath.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    const Text(
                      'File Path:',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    SelectableText(
                      _filePath,
                      style: const TextStyle(
                        fontSize: 12,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _controller,
            decoration: const InputDecoration(
              labelText: 'Enter Text',
              hintText: 'Type something to save to file',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.edit),
            ),
            maxLines: 4,
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _writeFile,
                  icon: const Icon(Icons.save),
                  label: const Text('Write File'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.all(16),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _readFile,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Read File'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.all(16),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Card(
            color: Colors.grey.shade100,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'File Content',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      if (_fileExists)
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () async {
                            final result = await showDialog<bool>(
                              context: context,
                              builder: (context) => AlertDialog(
                                title: const Text('Delete File'),
                                content: const Text(
                                  'Are you sure you want to delete the file?',
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(context, false),
                                    child: const Text('Cancel'),
                                  ),
                                  ElevatedButton(
                                    onPressed: () => Navigator.pop(context, true),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.red,
                                    ),
                                    child: const Text('Delete'),
                                  ),
                                ],
                              ),
                            );
                            if (result == true) {
                              _deleteFile();
                            }
                          },
                          tooltip: 'Delete file',
                        ),
                    ],
                  ),
                  const Divider(),
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.grey.shade300),
                    ),
                    child: Text(
                      _fileContent.isEmpty
                          ? 'No content yet. Write something first!'
                          : _fileContent,
                      style: TextStyle(
                        fontSize: 14,
                        color: _fileContent.isEmpty
                            ? Colors.grey
                            : Colors.black,
                        fontStyle: _fileContent.isEmpty
                            ? FontStyle.italic
                            : FontStyle.normal,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Card(
            color: Colors.blue,
            child: Padding(
              padding: EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'ℹ️ How it works:',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    '• Uses path_provider to get document directory\n'
                    '• Creates user_data.txt file\n'
                    '• Write: Saves text to file\n'
                    '• Read: Loads and displays file content\n'
                    '• Delete: Removes the file',
                    style: TextStyle(color: Colors.white),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
